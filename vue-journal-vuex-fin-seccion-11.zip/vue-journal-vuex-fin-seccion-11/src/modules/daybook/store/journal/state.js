
export default () => ({
    isLoading: true,
    entries: [
        {
            id: '1', // 12371298317892
            date: new Date().toDateString(), // sat 23, julio
            text: 'Minim exercitation ad nulla occaecat eiusmod qui enim amet voluptate incididunt esse. Consequat aute cillum laborum in. Est ullamco cillum aute do consequat culpa do non est consequat anim aliqua. Proident nostrud aute sit nisi velit. Tempor officia mollit quis eu aute deserunt laborum est ullamco minim. Do consectetur irure eu dolore reprehenderit dolor qui fugiat aliquip enim qui duis nisi sit. Aliqua velit non nostrud reprehenderit aliquip exercitation anim tempor sint irure aliquip.',
            picture: null, // https://
        },
        {
            id: '2', // 12371298317892
            date: new Date().toDateString(), // sat 23, julio
            text: 'Voluptate culpa sit ea nisi labore amet fugiat cupidatat duis culpa ex adipisicing enim quis. Ea aliquip laboris Lorem do irure amet qui fugiat. Officia laboris consectetur sint mollit est est aute mollit ut labore quis id do.',
            picture: null, // https://
        },
        {
            id: '3', // 12371298317892
            date: new Date().toDateString(), // sat 23, julio
            text: 'Fugiat consequat consectetur deserunt esse labore proident sit cupidatat nisi commodo eiusmod occaecat occaecat. Aute dolore voluptate ut id reprehenderit cupidatat cillum. Duis nisi magna est fugiat ut eu. Veniam consectetur in nulla officia eiusmod qui ad pariatur culpa eiusmod duis sint Lorem sit. Sunt proident veniam culpa labore sit enim ad ad.',
            picture: null, // https://
        },
    ]
})