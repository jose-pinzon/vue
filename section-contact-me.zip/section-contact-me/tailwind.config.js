module.exports = {
  mode: 'jit',
  content: ['./public/index.html', './src/**/*.{vue,ts}'],
}
