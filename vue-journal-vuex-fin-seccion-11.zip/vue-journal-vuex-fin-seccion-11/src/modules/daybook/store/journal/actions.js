
// export const myAction = async ({ commit }) => {

// }

export const loadEntries = async (/*{ commit }*/) => {

}

export const updateEntry = async (/*{ commit }*/) => {

}


export const createEntry = async (/*{ commit }*/) => {

}
