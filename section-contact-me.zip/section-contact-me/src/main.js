import { createApp } from 'vue'
import './assets/styles.css'
import App from './App.vue'
import './registerServiceWorker'

createApp(App).mount('#app')
